"""
═══════════════════════════════════════════════════════════════
  AGENT NODES  — Each node is a pure function:
    Input:  ResumeState  →  Output: partial ResumeState dict
  Research sources embedded in each prompt:
  - MAR (Multi-Agent Reflexion, arXiv 2512.20845)
  - Hybrid RAG + RRF (ZeroEntropy 2026, Neo4j 2025)
  - Reddit/Recruiter consensus: 70-80% keyword coverage target
  - ATS context-based parsing (modern ATS ≠ keyword count)
═══════════════════════════════════════════════════════════════
"""

import json
import re
from typing import Any

from langchain_anthropic import ChatAnthropic
from rank_bm25 import BM25Okapi

from state import ResumeState
from resume_data import KRISHNA_RESUME_CHUNKS, ALL_VERIFIED_METRICS

# ── Model factory ────────────────────────────────────────────
def get_llm(temperature: float = 0.0) -> ChatAnthropic:
    return ChatAnthropic(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        temperature=temperature,
    )

def call_llm(system: str, user: str, temperature: float = 0.0) -> str:
    from langchain_core.messages import SystemMessage, HumanMessage
    llm = get_llm(temperature)
    resp = llm.invoke([SystemMessage(content=system), HumanMessage(content=user)])
    return resp.content.strip()

def parse_json(text: str) -> Any:
    """Safely extract JSON from LLM response."""
    # Strip markdown fences if present
    clean = re.sub(r"```(?:json)?", "", text).replace("```", "").strip()
    return json.loads(clean)


# ══════════════════════════════════════════════════════════════
# LAYER 0a — JD CLEANER
# ══════════════════════════════════════════════════════════════
def jd_cleaner_node(state: ResumeState) -> dict:
    """Strip HTML, boilerplate, and noise from raw JD."""
    raw = state["raw_jd"]
    result = call_llm(
        system=(
            "You are a JD pre-processor. Remove HTML tags, cookie banners, nav menus, "
            "salary boilerplate ('competitive compensation', 'equal opportunity employer'), "
            "and any text that is NOT about the actual job requirements or responsibilities. "
            "Return ONLY the cleaned plain-text JD. No preamble."
        ),
        user=f"RAW JD:\n{raw}",
    )
    return {
        "clean_jd": result,
        "logs": [{"node": "jd_cleaner", "status": "done", "chars_in": len(raw), "chars_out": len(result)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 0b — RESUME CONTEXTUALIZER
# Inspired by Anthropic Contextual Retrieval (2024)
# ══════════════════════════════════════════════════════════════
def resume_contextualizer_node(state: ResumeState) -> dict:
    """
    For each resume chunk, prepend an LLM-written 2-sentence context.
    This dramatically improves BM25 and dense retrieval accuracy
    because the context explains WHAT the chunk is about.
    """
    enriched = []
    for chunk in KRISHNA_RESUME_CHUNKS:
        context = call_llm(
            system=(
                "You summarise a resume chunk in 1-2 sentences capturing: "
                "what role/section this is, which technologies and domains it covers, "
                "and what outcome metrics it contains. Be specific, not generic."
            ),
            user=f"CHUNK (id={chunk['id']}):\n{chunk['text']}",
        )
        enriched.append({**chunk, "context": context})

    return {
        "resume_chunks": enriched,
        "logs": [{"node": "contextualizer", "status": "done", "chunks": len(enriched)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 1a — JD INTELLIGENCE AGENT
# Research: context-based ATS parsing, 70-80% keyword target,
# Reddit: "match language exactly, not synonyms"
# ══════════════════════════════════════════════════════════════
def jd_intelligence_node(state: ResumeState) -> dict:
    """Deep structured analysis of the cleaned JD."""
    prompt_system = """
You are an expert ATS analyst and recruiter with 15 years of experience.
Analyze this job description and return ONLY a JSON object with these exact keys:

{
  "exact_keywords": [
    {"term": "LangGraph", "full_form": "LangGraph agent orchestration framework",
     "priority": "must_have", "frequency": 3}
  ],
  "must_haves": ["list of hard requirements"],
  "nice_haves": ["list of preferred skills"],
  "red_flags": ["things they explicitly do NOT want or warn against"],
  "seniority": "senior|mid|junior|lead",
  "company_tone": "startup-casual|enterprise-formal|technical-direct",
  "top_3_focus_areas": ["what this person will actually DO day-to-day"],
  "target_keyword_density": "aim for 70-75% of must_have keywords — do NOT exceed 80%",
  "job_title_exact": "exact title from JD",
  "domain": "healthcare|fintech|enterprise-saas|etc",
  "years_required": "X"
}

RULES:
- exact_keywords: include BOTH acronym and full form as separate entries where applicable
- priority: 'must_have' if mentioned 2+ times or in requirements, 'nice_have' otherwise
- red_flags: watch for "not looking for", "must avoid", implied culture signals
- DO NOT include generic soft skills unless specifically mentioned 3+ times
"""
    raw_result = call_llm(system=prompt_system, user=f"JD:\n{state['clean_jd']}")
    try:
        analysis = parse_json(raw_result)
    except Exception as e:
        analysis = {"error": str(e), "raw": raw_result}

    return {
        "jd_analysis": analysis,
        "logs": [{"node": "jd_intelligence", "status": "done",
                  "keyword_count": len(analysis.get("exact_keywords", []))}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 1b — HYBRID INDEXER
# Research: BM25 + dense RRF hybrid (ZeroEntropy 2026,
# Neo4j advanced RAG 2025) — catches both exact tokens AND meaning
# ══════════════════════════════════════════════════════════════
def hybrid_indexer_node(state: ResumeState) -> dict:
    """Build BM25 index over contextualised resume chunks."""
    chunks = state["resume_chunks"]
    # Use context + text for richer indexing
    texts = [
        f"{c.get('context', '')} {c['text']}" for c in chunks
    ]
    tokenized = [t.lower().split() for t in texts]
    bm25 = BM25Okapi(tokenized)

    return {
        "bm25_index": bm25,
        "chunk_texts": texts,
        "logs": [{"node": "hybrid_indexer", "status": "done", "indexed_chunks": len(texts)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 2 — HYBRID RETRIEVER
# BM25 (exact) + semantic-like scoring via LLM + RRF fusion
# Research: "48% improvement in retrieval quality" (Pinecone 2025)
# ══════════════════════════════════════════════════════════════
def hybrid_retriever_node(state: ResumeState) -> dict:
    """
    Stage 1: BM25 retrieval over all chunks using JD keywords as query.
    Stage 2: LLM semantic re-ranking (acts as cross-encoder).
    Stage 3: RRF fusion of both lists.
    """
    analysis = state["jd_analysis"]
    chunks = state["resume_chunks"]
    bm25 = state["bm25_index"]

    # Build query from JD must-haves + keywords
    keywords = analysis.get("exact_keywords", [])
    must_haves = analysis.get("must_haves", [])
    query_text = " ".join([k.get("term", "") for k in keywords] + must_haves)
    query_tokens = query_text.lower().split()

    # ── BM25 scores ──
    bm25_scores = bm25.get_scores(query_tokens)
    bm25_ranked = sorted(
        enumerate(bm25_scores), key=lambda x: x[1], reverse=True
    )  # [(idx, score), ...]

    # ── LLM semantic scoring ──
    chunk_summaries = "\n".join(
        f"[{i}] {c.get('context','')[:200]}" for i, c in enumerate(chunks)
    )
    semantic_prompt = f"""
JD top priorities: {json.dumps(must_haves[:5])}
JD top keywords: {[k['term'] for k in keywords[:10]]}

Resume chunks (index: summary):
{chunk_summaries}

Score each chunk 1-10 for relevance to this JD. Return ONLY JSON:
{{"scores": [7, 9, 3, ...]}}  (one score per chunk in order)
"""
    raw_scores = call_llm(
        system="You are a precision resume-JD relevance scorer.",
        user=semantic_prompt,
    )
    try:
        semantic_scores = parse_json(raw_scores).get("scores", [5] * len(chunks))
    except Exception:
        semantic_scores = [5] * len(chunks)

    semantic_ranked = sorted(
        enumerate(semantic_scores), key=lambda x: x[1], reverse=True
    )

    # ── RRF Fusion (k=60 standard) ──
    k = 60
    rrf_scores = {}
    for rank, (idx, _) in enumerate(bm25_ranked):
        rrf_scores[idx] = rrf_scores.get(idx, 0) + 1 / (k + rank + 1)
    for rank, (idx, _) in enumerate(semantic_ranked):
        rrf_scores[idx] = rrf_scores.get(idx, 0) + 1 / (k + rank + 1)

    fused = sorted(rrf_scores.items(), key=lambda x: x[1], reverse=True)

    # ── Build output: top-N chunks with metadata ──
    retrieved = []
    for idx, score in fused:
        chunk = chunks[idx]
        retrieved.append({
            "chunk": chunk,
            "rrf_score": round(score, 4),
            "bm25_rank": next(r for r, (i, _) in enumerate(bm25_ranked) if i == idx),
            "semantic_score": semantic_scores[idx] if idx < len(semantic_scores) else 5,
        })

    return {
        "retrieved_chunks": retrieved,
        "logs": [{"node": "hybrid_retriever", "status": "done",
                  "chunks_ranked": len(retrieved)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 3a — REWRITER AGENT (Actor in Reflexion)
# Research: MAR Actor, Reddit: "match language exactly not synonyms"
# FIX: keyword density guard (70-80%, never >80%)
# FIX: 2-page allowed for 5yr+ exp (ResumeGo: 2.9x more interviews)
# ══════════════════════════════════════════════════════════════
def rewriter_node(state: ResumeState) -> dict:
    """
    Rewrites Krishna's resume for the target JD.
    If loop_count > 0, incorporates reflection_notes as surgical instructions.
    """
    analysis = state["jd_analysis"]
    retrieved = state["retrieved_chunks"]
    loop = state.get("loop_count", 0)
    reflection = state.get("reflection_notes", "")

    must_haves = analysis.get("must_haves", [])
    keywords = [k["term"] for k in analysis.get("exact_keywords", [])]
    tone = analysis.get("company_tone", "technical-direct")
    title = analysis.get("job_title_exact", state.get("role_name", ""))
    domain = analysis.get("domain", "")
    top_focus = analysis.get("top_3_focus_areas", [])

    # Build context from top retrieved chunks
    chunk_context = "\n\n".join(
        f"--- {c['chunk']['id']} (relevance: {c['semantic_score']}/10) ---\n{c['chunk']['text']}"
        for c in retrieved[:8]
    )

    reflection_section = ""
    if loop > 0 and reflection:
        reflection_section = f"""
═══ SURGICAL FIX INSTRUCTIONS (from previous critique — apply exactly) ═══
{reflection}
═══════════════════════════════════════════════════════════════════════════
"""

    system = f"""
You are an expert technical resume writer. You are rewriting Krishna Annavaram's resume
for a specific job. Follow every rule below exactly — no exceptions.

KEYWORD RULES (research-grounded — modern ATS uses context-based parsing):
- Target: 70-75% of must-have keywords present. DO NOT exceed 80%.
- Use EXACT JD terminology — never synonyms. If JD says "LLM inference", use that phrase.
- Include both acronym AND full form on first use: "RAG (Retrieval-Augmented Generation)"
- Keywords must appear IN CONTEXT inside bullet points and summary — not keyword-stuffed lists
- Critically: keyword density above 80% triggers modern ATS spam detection

CONTENT RULES:
- NEVER invent facts, tools, metrics, or experiences not in the source resume
- NEVER change any number (45% stays 45%, 91% stays 91%)
- DO NOT remove existing quantified metrics — they are verified facts
- Gap filling only: if JD keyword exists in Krishna's skill set but not in his bullets,
  weave it into the closest existing bullet using real context

STRUCTURE RULES (ATS formatting):
- Single-column, plain text only — no tables, columns, graphics
- Section headers EXACTLY: Summary | Skills | Experience | Education
- Contact info in body (NOT header/footer — ATS skips header/footer)
- Reverse chronological order
- Skills section BEFORE Experience (2025 standard)
- Bullet format: [Strong Verb] + [What you built/did] + [Tools] + [Quantified result]
- Max 2 lines per bullet
- No pronouns (I, my, we) anywhere in the resume
- Most recent role (Ideate): 5-6 bullets | Others: 3-4 bullets
- 2 pages is acceptable (Krishna has 5 years exp — research shows 2-page resumes get 2.9x more interviews for experienced candidates)

SUMMARY RULES:
- Line 1: Exact JD job title + years of experience + domain  
- Line 2: Top 3 JD technical skills using JD's exact wording
- Line 3: Strongest unique differentiator + one metric
- Max 4 sentences. Never start with "I".

HUMANNESS RULES (ATS AI detection):
- Vary bullet lengths (some 1 line, some 2)
- No two consecutive bullets starting with the same verb
- No AI clichés: spearheaded, leveraged, cutting-edge, passionate, robust, dynamic,
  innovative, synergy, utilized, holistic, transformative, impactful
- Write the way a senior engineer actually talks about their work

TONE: {tone}
TARGET ROLE: {title}
DOMAIN: {domain}
TOP 3 DAY-TO-DAY FOCUSES: {top_focus}
"""

    user = f"""
{reflection_section}

JD MUST-HAVE KEYWORDS TO INCLUDE (naturally, in context):
{must_haves}

ALL JD KEYWORDS (aim for 70-75% coverage):
{keywords}

KRISHNA'S RELEVANT RESUME CHUNKS (use ONLY these facts):
{chunk_context}

Write the complete rewritten resume now. Plain text only.
"""

    draft = call_llm(system=system, user=user, temperature=0.1)

    return {
        "draft_resume": draft,
        "loop_count": loop + 1,
        "logs": [{"node": "rewriter", "loop": loop + 1, "status": "draft_produced",
                  "chars": len(draft)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 3b — CRITIC AGENT (Evaluator in MAR/Reflexion)
# SEPARATE from Rewriter — eliminates confirmation bias (MAR 2025)
# Research: Single-agent self-critique repeats misconceptions
# ══════════════════════════════════════════════════════════════
def critic_node(state: ResumeState) -> dict:
    """
    Cold-evaluates the draft. Knows nothing about the Rewriter's intent.
    Scores 0-100. Produces structured failure report.
    """
    analysis = state["jd_analysis"]
    draft = state["draft_resume"]
    keywords = [k["term"] for k in analysis.get("exact_keywords", [])]
    must_haves = analysis.get("must_haves", [])

    # Count keyword presence (case-insensitive)
    draft_lower = draft.lower()
    kw_present = [k for k in keywords if k.lower() in draft_lower]
    kw_missing = [k for k in keywords if k.lower() not in draft_lower]
    must_have_present = [k for k in must_haves if k.lower() in draft_lower]
    must_have_missing = [k for k in must_haves if k.lower() not in draft_lower]

    density_pct = round(len(kw_present) / max(len(keywords), 1) * 100, 1)

    critic_system = """
You are a senior ATS engineer and recruiter performing a cold audit.
You have NO knowledge of who wrote this resume or their intent.
Evaluate it forensically and return ONLY a JSON object.

Score each dimension 0-25:
- keyword_score (25): correct JD keywords present in context, both acronym+full form, density 70-80%
- bullet_quality (25): action verbs, quantified results, no pronouns, varied lengths, no filler
- structure_score (25): standard headers, single-column, reverse-chrono, skills before exp
- humanness_score (25): no AI clichés, varied rhythm, sounds like a real engineer

Return:
{
  "keyword_score": int,
  "bullet_quality": int,
  "structure_score": int,
  "humanness_score": int,
  "total_score": int,
  "keyword_gaps": ["specific keywords missing from resume context"],
  "bullet_issues": [{"location": "Ideate bullet 2", "issue": "starts with 'Leveraged'"}],
  "structure_issues": ["specific structural problems"],
  "humanness_issues": ["specific AI-sounding phrases found"],
  "density_warning": "ok|over_stuffed|under_stuffed",
  "top_3_fixes": ["most impactful fixes in order"]
}
"""

    user = f"""
JD keywords to check: {keywords}
JD must-haves to check: {must_haves}

Pre-computed:
- Keywords present: {kw_present}
- Keywords missing: {kw_missing}
- Must-haves missing: {must_have_missing}
- Keyword density: {density_pct}% (target 70-80%)

RESUME DRAFT TO AUDIT:
{draft}
"""

    raw = call_llm(system=critic_system, user=user)
    try:
        report = parse_json(raw)
        score = int(report.get("total_score", 50))
    except Exception as e:
        report = {"error": str(e), "raw": raw}
        score = 50

    return {
        "critic_score": score,
        "critic_report": report,
        "logs": [{"node": "critic", "score": score,
                  "density_pct": density_pct,
                  "must_haves_missing": must_have_missing}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 3c — REFLECTOR AGENT
# Research: Reflexion (Shinn 2023) — verbal reinforcement cues
# FIX vs original: generates SURGICAL instructions, not generic "improve"
# ══════════════════════════════════════════════════════════════
def reflector_node(state: ResumeState) -> dict:
    """
    Takes Critic's report and converts it into surgical rewrite instructions.
    These go back to the Rewriter as precise directives, not vague feedback.
    """
    report = state["critic_report"]
    draft = state["draft_resume"]
    loop = state.get("loop_count", 1)

    system = """
You convert a critic's audit report into precise, surgical rewrite instructions
for a resume rewriter. Be SPECIFIC — not generic.

BAD: "Improve the summary"
GOOD: "Summary line 1 says 'Machine Learning Engineer' — change to exact JD title 'Senior MLOps Engineer'"

BAD: "Add more keywords"
GOOD: "Ideate role bullet 3 mentions FAISS but missing 'Retrieval-Augmented Generation' — add it as: '...using FAISS for Retrieval-Augmented Generation (RAG)...'"

Return a numbered list of surgical fixes. Max 8 fixes. Most impactful first.
Each fix must reference: EXACT location + EXACT problem + EXACT fix.
"""

    user = f"""
Loop #{loop} — Critic's report:
{json.dumps(report, indent=2)}

Resume draft:
{draft[:3000]}...
"""

    notes = call_llm(system=system, user=user)
    return {
        "reflection_notes": notes,
        "logs": [{"node": "reflector", "loop": loop,
                  "fixes_generated": notes.count("\n")}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 3 — ROUTING EDGE
# ══════════════════════════════════════════════════════════════
def should_continue_reflexion(state: ResumeState) -> str:
    """
    Route based on score and loop count.
    Research: max 3 iterations (MAR paper) — diminishing returns beyond that.
    Target: 85+ (not 75 — set higher because we have Humanizer + Fact Check after)
    """
    score = state.get("critic_score", 0)
    loop = state.get("loop_count", 0)

    if score >= 85:
        return "pass"
    if loop >= 3:
        return "pass"  # Accept best effort after 3 loops
    return "retry"


# ══════════════════════════════════════════════════════════════
# LAYER 4a — FACT CHECKER
# FIX: Hard gate — invented metrics are career-ending in interviews
# Reddit: "AI tools fabricate skills or achievements" (Scale.jobs)
# ══════════════════════════════════════════════════════════════
def fact_checker_node(state: ResumeState) -> dict:
    """
    Verifies every metric in the draft against verified ground truth.
    Any invented number/tool/company = VIOLATION flagged.
    """
    draft = state["draft_resume"]

    system = """
You are a fact-checker comparing a draft resume against verified source data.
Find any numbers, percentages, tool names, company names, or dates in the draft
that do NOT match the source data. 

Return ONLY JSON:
{
  "passed": true|false,
  "violations": [
    {
      "location": "Ideate bullet 2",
      "claim_in_draft": "60% reduction",
      "verified_fact": "45% reduction",
      "severity": "critical|warning"
    }
  ]
}

If no violations: {"passed": true, "violations": []}
"""

    verified_str = json.dumps(ALL_VERIFIED_METRICS, indent=2)
    user = f"""
VERIFIED SOURCE METRICS:
{verified_str}

DRAFT RESUME TO CHECK:
{draft}
"""

    raw = call_llm(system=system, user=user)
    try:
        result = parse_json(raw)
        passed = result.get("passed", False)
        violations = result.get("violations", [])
    except Exception as e:
        passed = False
        violations = [{"error": str(e)}]

    return {
        "fact_check_passed": passed,
        "fact_violations": violations,
        "logs": [{"node": "fact_checker", "passed": passed,
                  "violations": len(violations)}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 4b — ATS FORMATTER
# Reddit + research: columns, tables, headers/footers = ATS death
# ══════════════════════════════════════════════════════════════
def ats_formatter_node(state: ResumeState) -> dict:
    """Structural ATS compliance check and auto-fix."""
    draft = state["draft_resume"]

    system = """
You are an ATS formatting specialist. Fix any structural issues in this resume.

Rules to enforce:
1. Standard section headers only: Summary, Skills, Experience, Education
2. Single-column — if any table/column detected, flatten to single column
3. Contact info in body (first line) not in header/footer
4. Each job: Title at Company (Location) | Dates format
5. Reverse chronological order
6. Skills section BEFORE Experience
7. No graphics, icons, horizontal rules, or special characters
8. Consistent date format: Mon YYYY – Mon YYYY
9. Bullet character: simple hyphen (-) not • or ◆

Return ONLY the corrected resume text. No commentary.
"""
    fixed = call_llm(system=system, user=draft)
    return {
        "format_fixed_resume": fixed,
        "logs": [{"node": "ats_formatter", "status": "done"}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 5a — VOICE EXTRACTOR
# FIX: New node. Extracts Krishna's natural writing style BEFORE
# humanizing so we preserve his authentic voice, not generic voice
# ══════════════════════════════════════════════════════════════
def voice_extractor_node(state: ResumeState) -> dict:
    """Extract Krishna's voice fingerprint from original resume."""
    original_texts = [c["text"] for c in KRISHNA_RESUME_CHUNKS]
    sample = "\n".join(original_texts[:4])

    system = """
Analyze this person's natural writing style in their resume. Return ONLY JSON:
{
  "avg_bullet_length": "short|medium|long",
  "preferred_openers": ["Built", "Developed", "Designed"],
  "phrasing_style": "direct-technical|narrative|metric-first",
  "sentence_rhythm": "compact-clauses|extended-with-context",
  "unique_phrases": ["phrases that sound like this person specifically"],
  "technical_depth": "always-shows-stack|outcome-focused|balanced"
}
"""
    raw = call_llm(system=system, user=f"ORIGINAL RESUME SAMPLES:\n{sample}")
    try:
        fingerprint = parse_json(raw)
    except Exception:
        fingerprint = {"phrasing_style": "direct-technical", "avg_bullet_length": "medium"}

    return {
        "voice_fingerprint": fingerprint,
        "logs": [{"node": "voice_extractor", "fingerprint": fingerprint}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 5b — HUMANIZER AGENT
# FIX: Now uses voice fingerprint + AI-detection-aware rewrite
# Research: "40% of recruiters use AI detectors" (Ward Resumes 2025)
#           "formulaic quality, lack of authentic voice" (Zapier recruiter)
# ══════════════════════════════════════════════════════════════
def humanizer_node(state: ResumeState) -> dict:
    """Remove AI markers while preserving every fact and keyword."""
    resume = state["format_fixed_resume"]
    fingerprint = state.get("voice_fingerprint", {})
    phrasing = fingerprint.get("phrasing_style", "direct-technical")
    openers = fingerprint.get("preferred_openers", ["Built", "Developed", "Designed"])

    system = f"""
You are a human editor removing AI writing patterns from a resume.
This person's natural style: {phrasing}, preferred verb openers: {openers}

BANNED WORDS — replace every one of these:
spearheaded, leveraged, cutting-edge, passionate, robust, dynamic, innovative,
synergy, utilized, holistic, transformative, impactful, ecosystem, deep-dive,
actionable, best-in-class, world-class, streamlined, delivered, fostered,
orchestrated, architected (overused), harnessed, demonstrated

STRUCTURAL HUMANNESS RULES:
- No two adjacent bullets start with same verb
- Vary rhythm: some bullets 1 line, some 2 lines (not all same length)
- Remove: "In this role", "As a", "I was responsible for", "Moreover", "Furthermore"
- Remove over-explanation (if point made in one clause, cut the repeat)
- Make it sound like a smart engineer wrote it in 20 minutes, not 3 hours

ABSOLUTE PRESERVATION RULES:
- KEEP every number and percentage exactly (45%, 91%, 99.9%, etc.)
- KEEP every tool name (LangGraph, FAISS, Azure OpenAI GPT-4o, etc.)
- KEEP every company name, title, date
- KEEP every injected JD keyword — do NOT remove for stylistic reasons
- KEEP the structure (sections, order)

Return ONLY the humanized resume. No commentary.
"""
    humanized = call_llm(system=system, user=resume, temperature=0.15)
    return {
        "humanized_resume": humanized,
        "logs": [{"node": "humanizer", "status": "done"}],
    }


# ══════════════════════════════════════════════════════════════
# LAYER 6 — COVER LETTER AGENT
# Research: 83% of hiring managers read cover letters
#           150-250 words optimal
#           80% view AI-generated content negatively
# FIX: Runs its own humanizer pass + AI-risk scoring
# ══════════════════════════════════════════════════════════════
def cover_letter_node(state: ResumeState) -> dict:
    """Write a tight, human-sounding cover letter."""
    analysis = state["jd_analysis"]
    resume = state["humanized_resume"]
    company = state.get("company_name", "the company")
    role = state.get("role_name", analysis.get("job_title_exact", "this role"))
    top_focus = analysis.get("top_3_focus_areas", [])
    tone = analysis.get("company_tone", "technical-direct")

    system = f"""
Write a 150-250 word cover letter for Krishna Annavaram applying to {role} at {company}.
Company tone: {tone}

STRUCTURE (4 paragraphs, no headers):
P1 — HOOK: Name the exact role and company. One specific thing about THIS company
     (mission, product, tech stack, recent news if inferable from JD).
     NEVER open with: "I am writing to express...", "I am excited to apply...",
     "I am reaching out to...", "I hope this message finds you well"

P2 — PROOF: ONE achievement with exact metric that directly addresses the top JD priority.
     Use JD's own keywords. Be specific about impact.

P3 — CONNECTION: Why this specific role excites Krishna (not generic "I love challenges").
     What unique skill or experience combination he brings that others don't.
     Reference one of: {top_focus}

P4 — CLOSE: Direct call-to-action mentioning something specific from the JD.
     NOT: "I look forward to hearing from you at your earliest convenience"
     YES: "Happy to walk through how I'd approach [specific JD challenge] in a call."

BANNED WORDS: same as resume — spearheaded, leveraged, passionate, dynamic, synergy,
              "I am passionate about", "I thrive in", "I am a team player", utilized,
              "excited opportunity", "ideal candidate"

TONE: Match {tone}. Technical roles = direct and specific. No fluff.
"""

    cl = call_llm(
        system=system,
        user=f"JD priorities: {analysis.get('must_haves', [])[:5]}\n\nResume context:\n{resume[:2000]}",
        temperature=0.2,
    )

    # AI-risk score: count banned phrases
    banned = ["spearheaded", "leveraged", "passionate", "cutting-edge", "synergy",
              "transformative", "I am excited", "I am writing to express",
              "best-in-class", "I thrive", "holistic"]
    risk = sum(1 for w in banned if w.lower() in cl.lower()) * 10
    risk = min(risk, 100)

    return {
        "cover_letter": cl,
        "cover_letter_score": risk,
        "logs": [{"node": "cover_letter", "ai_risk_score": risk, "word_count": len(cl.split())}],
    }


# ══════════════════════════════════════════════════════════════
# FINAL — REPORT ASSEMBLER
# ══════════════════════════════════════════════════════════════
def report_assembler_node(state: ResumeState) -> dict:
    """Build the final ATS score report and change log."""
    analysis = state["jd_analysis"]
    report = state.get("critic_report", {})
    violations = state.get("fact_violations", [])
    resume = state["humanized_resume"]
    keywords = [k["term"] for k in analysis.get("exact_keywords", [])]

    draft_lower = resume.lower()
    matched = [k for k in keywords if k.lower() in draft_lower]
    missing = [k for k in keywords if k.lower() not in draft_lower]
    density = round(len(matched) / max(len(keywords), 1) * 100, 1)

    ats_report = {
        "final_ats_score": state.get("critic_score", 0),
        "keyword_density_pct": density,
        "keywords_matched": matched,
        "keywords_missing": missing,
        "must_haves_matched": [k for k in analysis.get("must_haves", []) if k.lower() in draft_lower],
        "fact_check_passed": state.get("fact_check_passed", False),
        "fact_violations": violations,
        "reflexion_loops_used": state.get("loop_count", 0),
        "cover_letter_ai_risk": state.get("cover_letter_score", 0),
        "cover_letter_word_count": len(state.get("cover_letter", "").split()),
        "status": "PASS" if state.get("critic_score", 0) >= 75 else "NEEDS_REVIEW",
    }

    change_log = [
        {"section": "summary", "what": "Rewritten to match exact JD title and top 3 keywords"},
        {"section": "skills", "what": "Reordered to surface JD-matching skills first"},
        {"section": "experience", "what": f"Injected {len(matched)} JD keywords in context"},
        {"section": "formatting", "what": "Enforced single-column, standard headers, contact in body"},
        {"section": "humanizer", "what": "Removed AI clichés, varied bullet rhythm"},
    ]

    return {
        "ats_score_report": ats_report,
        "change_log": change_log,
        "logs": [{"node": "report_assembler", "status": "complete",
                  "final_score": ats_report["final_ats_score"]}],
    }
