"""
Krishna Annavaram's resume stored as typed chunks.
Each chunk has: id, section, role_rank, text, metrics[]
Metrics are extracted separately so the Fact Checker can verify them
without re-parsing free text.
"""

KRISHNA_RESUME_CHUNKS = [
    {
        "id": "summary",
        "section": "summary",
        "role_rank": None,
        "text": (
            "Generative AI Engineer with 5 years of experience building production-grade "
            "GenAI and ML systems across healthcare and enterprise domains. Specializes in "
            "RAG pipelines, LangGraph agent orchestration, embeddings, prompt engineering "
            "workflows, and API deployments. Proficient in Python, PyTorch, TensorFlow, "
            "FastAPI, and cloud platforms (AWS, GCP, Azure). Deep expertise in healthcare "
            "payer data including claims, billing, and utilization management under "
            "HIPAA-compliant architectures."
        ),
        "metrics": ["5 years"],
    },
    {
        "id": "job_ideate",
        "section": "experience",
        "role_rank": 1,
        "company": "Ideate Technologies LLC",
        "title": "Generative AI Engineer",
        "location": "TX, USA",
        "dates": "Jan 2025 – Present",
        "text": (
            "Built Graph-RAG Clinical Decision Support system using Neo4j, FAISS, and "
            "Azure OpenAI GPT-4o, achieving 45% reduction in unsafe clinical recommendations "
            "and 91% retrieval accuracy. "
            "Developed voice-based patient intake automation with Azure STT, LangGraph, "
            "CosmosDB, and Claude 3, automating 85% of patient interactions. "
            "Designed multi-agent orchestration framework using LangGraph A2A/MCP protocols "
            "integrated with FHIR EHR systems under HIPAA compliance. "
            "Fine-tuned Long-T5 and BART models using PEFT/LoRA, achieving 92% handoff "
            "completeness and reducing physician review workload by 50%. "
            "Deployed CI/CD pipelines on AKS with Azure ML, MLflow, Terraform, and GitHub "
            "Actions, maintaining 99.9% system availability."
        ),
        "metrics": ["45%", "91%", "85%", "92%", "50%", "99.9%"],
    },
    {
        "id": "job_unt",
        "section": "experience",
        "role_rank": 2,
        "company": "University of North Texas",
        "title": "Graduate Teaching Assistant",
        "location": "TX, USA",
        "dates": "Aug 2024 – Dec 2024",
        "text": (
            "Built AI research assistance system using RAG, FAISS, PostgreSQL, and Redis, "
            "achieving 88-92% retrieval relevance and reducing faculty research effort by "
            "40-45%."
        ),
        "metrics": ["88%", "92%", "40%", "45%"],
    },
    {
        "id": "job_sunpharma",
        "section": "experience",
        "role_rank": 3,
        "company": "Sun Pharma",
        "title": "AI Engineer",
        "location": "India",
        "dates": "Nov 2022 – Dec 2023",
        "text": (
            "Designed GCP AI/ML pipelines using BigQuery, Dataflow, and AI Platform, "
            "improving operational efficiency by 30%. "
            "Developed BERT NLP models for drug interaction analysis using TensorFlow 2.x. "
            "Built XGBoost sales forecasting models, reducing marketing inefficiency by 15%. "
            "Automated ETL workflows and implemented CI/CD using GitHub Actions and Cloud Build."
        ),
        "metrics": ["30%", "15%"],
    },
    {
        "id": "job_cognizant",
        "section": "experience",
        "role_rank": 4,
        "company": "Cognizant Technology Solutions",
        "title": "Machine Learning Consultant",
        "location": "India",
        "dates": "Aug 2021 – Nov 2022",
        "text": (
            "Developed healthcare claims and incentive ML pipelines using Python, SQL, and "
            "AWS, improving accuracy by 35%. "
            "Built feature engineering pipelines for SAP ICM and Workday integrations using "
            "Pandas, reducing manual effort by 55%. "
            "Deployed ML inference on AWS SageMaker and Lambda; built data marts with "
            "S3 and Athena; implemented MLOps using AWS CodePipeline."
        ),
        "metrics": ["35%", "55%"],
    },
    {
        "id": "job_lemoius",
        "section": "experience",
        "role_rank": 5,
        "company": "Lemoius Pvt Ltd",
        "title": "Machine Learning Engineer",
        "location": "India",
        "dates": "May 2020 – Aug 2021",
        "text": (
            "Built resume-to-job recommendation system improving relevance by 35%. "
            "Developed BERT embeddings NLP pipelines improving matching accuracy by 30%. "
            "Implemented cosine similarity ranking, improving shortlisting quality by 25%."
        ),
        "metrics": ["35%", "30%", "25%"],
    },
    {
        "id": "skills_cloud",
        "section": "skills",
        "role_rank": None,
        "category": "Cloud Platforms",
        "text": (
            "AWS: S3, EC2, SageMaker, Bedrock, Lambda, Glue, Kinesis, ECS. "
            "GCP: BigQuery, Vertex AI, Dataflow, Dialogflow CX. "
            "Azure: Azure Machine Learning, CosmosDB, AKS, Databricks, Azure Data Factory."
        ),
        "metrics": [],
    },
    {
        "id": "skills_genai",
        "section": "skills",
        "role_rank": None,
        "category": "GenAI & LLM",
        "text": (
            "LangChain, LangGraph, LangSmith, HayStack, BERT, RoBERTa, GPT, LLaMA, "
            "Hugging Face Transformers, PEFT, LoRA, QLoRA, RLHF, RAG, Graph-RAG, "
            "FAISS, Chroma DB, Milvus, Pinecone, Weaviate."
        ),
        "metrics": [],
    },
    {
        "id": "skills_ml",
        "section": "skills",
        "role_rank": None,
        "category": "ML & Frameworks",
        "text": (
            "Python, SQL, R, Bash, Go, Scala, JavaScript, TypeScript. "
            "PyTorch, TensorFlow, FastAPI, XGBoost, scikit-learn. "
            "Docker, Kubernetes, Terraform, Airflow, Kubeflow, Jenkins, MLflow."
        ),
        "metrics": [],
    },
    {
        "id": "education",
        "section": "education",
        "role_rank": None,
        "text": (
            "MS Data Science (Applied NLP & Generative AI) — University of North Texas, TX. "
            "BTech Computer Science (Machine Learning & Deep Learning) — "
            "Kalasalingam University, India."
        ),
        "metrics": [],
    },
]

# All verified metrics across resume (for Fact Checker ground truth)
ALL_VERIFIED_METRICS = {
    "45%": "Graph-RAG unsafe recommendation reduction",
    "91%": "Graph-RAG retrieval accuracy",
    "85%": "Voice intake automation rate",
    "92%": "BART/Long-T5 handoff completeness",
    "50%": "Physician review reduction",
    "99.9%": "System availability (AKS deployment)",
    "88-92%": "UNT RAG retrieval relevance range",
    "40-45%": "UNT faculty effort reduction range",
    "30%": "Sun Pharma GCP pipeline efficiency gain",
    "15%": "Sun Pharma marketing inefficiency reduction",
    "35%": "Cognizant healthcare claims accuracy improvement",
    "55%": "Cognizant feature pipeline effort reduction",
    "35%": "Lemoius recommendation relevance improvement",
    "30%": "Lemoius BERT matching accuracy improvement",
    "25%": "Lemoius shortlisting quality improvement",
    "5 years": "Total experience",
}
