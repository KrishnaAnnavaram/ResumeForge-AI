# Krishna's AI Resume Optimizer
## Complete System Design, Flaw Analysis & LangGraph Implementation

---

## 🔴 FLAWS FOUND IN PREVIOUS DESIGN (and how each was fixed)

### FLAW 1: No keyword density ceiling
**Problem found via:** Reddit r/jobs, Scale.jobs research, ATS engineers  
**What was wrong:** Our system just maximized keyword inclusion with no upper bound.  
Modern ATS systems use context-based parsing — they DETECT and PENALIZE keyword stuffing.
One Reddit horror story: an engineer got auto-rejected because their AI tool stuffed "Python"
17 times. A real engineer would say it 3-4 times max.  
**Fix applied:** Critic agent now scores density. Target = 70–75%. Hard ceiling = 80%.
Rewriter system prompt explicitly says "DO NOT exceed 80% density."

---

### FLAW 2: Self-critique confirmation bias  
**Problem found via:** MAR paper (arXiv 2512.20845, Dec 2025)  
**What was wrong:** Our original ATS Validator was the same agent that wrote the resume.
Research proves: "the same model generates actions, evaluates behavior, and produces
reflections — which results in repeated reasoning errors and confirmation bias."  
**Fix applied:** Completely separate Critic agent with different system prompt and persona.
The Critic doesn't know it's evaluating its own output. This is the MAR (Multi-Agent
Reflexion) pattern — proven to improve HumanEval pass@1 by 6.2 points.

---

### FLAW 3: Generic reflection instructions  
**Problem found via:** Reflexion paper (Shinn et al. 2023), LangChain reflection blog  
**What was wrong:** After critique, the system gave vague feedback like "improve bullet 3."
Research shows: Reflexion works when the self-reflection model generates SPECIFIC verbal
reinforcement cues that are stored and used in the next attempt.  
**Fix applied:** New Reflector agent converts critique into surgical fixes:
"Ideate bullet 3 mentions FAISS but missing 'Retrieval-Augmented Generation' — 
add it as: '...using FAISS for Retrieval-Augmented Generation (RAG)...'"

---

### FLAW 4: Semantic-only retrieval  
**Problem found via:** Neo4j Advanced RAG (2025), ZeroEntropy reranking guide (2026)  
**What was wrong:** Pure vector/semantic retrieval misses exact keyword tokens.
"Without hybrid search, names and codes slip through." If JD says "LangGraph" and
resume says "agent orchestration framework," vector search may miss it.  
**Fix applied:** BM25 (exact keyword) + semantic scoring + RRF fusion.
Research shows 48% improvement in retrieval quality with this approach.

---

### FLAW 5: No human-in-the-loop checkpoint  
**Problem found via:** LangGraph HITL docs, Reddit recruiter feedback  
**What was wrong:** System ran end-to-end with no opportunity for review.
Reddit consensus: "AI is a first draft, not a final product." Recruiters want
to see human judgment applied.  
**Fix applied:** LangGraph `interrupt_before=["fact_checker"]` — graph pauses
after the reflexion loop. Krishna reviews the draft, approves or adds feedback,
then resumes. All state is preserved via MemorySaver checkpointing.

---

### FLAW 6: 1-page assumption for 5-year engineer  
**Problem found via:** ResumeGo study of 7,712 resumes (cited in ResumeFast 2026)  
**What was wrong:** System tried to compress everything to 1 page.
Data shows: 2-page resumes get 2.9x more interviews for experienced candidates.
Krishna has 5 years and 5 jobs — forcing 1 page means cutting important context.  
**Fix applied:** Rewriter prompt explicitly notes "2 pages acceptable for 5+ year candidates."

---

### FLAW 7: No AI-detection awareness  
**Problem found via:** Ward Resumes (2025), Built In article on AI resume detection  
**What was wrong:** The Humanizer just removed clichés but didn't address the structural
AI writing patterns that recruiters (and ATS AI detectors) recognize:
formulaic sentence structure, identical bullet lengths, same rhythm throughout.  
**Fix applied:** Voice Extractor node runs FIRST to extract Krishna's natural writing
fingerprint (rhythm, openers, phrasing style) from original resume. Humanizer then
rewrites to match his specific voice, not generic "humanized" output. Cover Letter
node includes its own AI-risk score.

---

### FLAW 8: No fact verification hard gate  
**Problem found via:** Scale.jobs, career coaches on Reddit  
**What was wrong:** AI tools "often fabricate skills or achievements" (Scale.jobs).
If the system inflated 45% to 60% and Krishna got asked about it in an interview,
it would be career-damaging.  
**Fix applied:** Dedicated Fact Checker node with ALL_VERIFIED_METRICS ground truth.
Compares every number in the draft against verified source. Critical violations
are flagged in the final report. This is a hard gate.

---

### FLAW 9: State management without reducers  
**Problem found via:** LangGraph State Management 2025 docs  
**What was wrong:** No explicit TypedDict schema or reducer functions defined.
In LangGraph, without reducers, parallel nodes overwrite each other's state.  
**Fix applied:** Full TypedDict ResumeState with Annotated reducers:
- `replace` for scalars (overwrite is correct)
- `append_log` for audit logs (never overwrite — append only)
This prevents state corruption in parallel node execution.

---

### FLAW 10: No parallel execution where possible  
**Problem found via:** Anthropic multi-agent engineering blog  
**What was wrong:** All 13 agents ran sequentially. But several have no dependencies
and can run simultaneously.  
**Fix applied:** Three parallel stages:
1. jd_cleaner + resume_contextualizer (L0, completely independent)
2. jd_intelligence + hybrid_indexer (L1, each depends on one L0 output only)
3. fact_checker + ats_formatter (L4, completely independent quality checks)

---

## 📐 FINAL SYSTEM ARCHITECTURE

```
START
  │
  ├──────────────────────────────────┐
  ▼                                  ▼
jd_cleaner                resume_contextualizer
(clean noise from JD)     (add LLM context to each chunk)
  │                                  │
  ▼                                  ▼
jd_intelligence           hybrid_indexer
(extract keywords,        (build BM25 + semantic index
 tone, must-haves,         over contextualised chunks)
 density target)                     │
  │                                  │
  └──────────────┬───────────────────┘
                 ▼
          hybrid_retriever
     (BM25 + semantic + RRF fusion
      → ranked relevant chunks)
                 │
                 ▼
            rewriter  ◄────────────────────┐
       (Actor — writes draft)              │
                 │                         │
                 ▼                         │
              critic                       │
      (Evaluator — cold audit,             │
       separate agent, no bias)            │
                 │                         │
         ┌───────┴────────┐                │
         │                │                │
        pass            retry              │
    (score≥85 or      (score<85         reflector
     loop≥3)           loop<3)    (surgical fix instructions)
         │                                 │
         └─────────────────────────────────┘
                 │
    ┌────────────▼────────────────────────┐
    │    HUMAN-IN-THE-LOOP INTERRUPT       │
    │    Krishna reviews draft here        │
    │    approve → resume                  │
    │    feedback → one more rewriter pass │
    └────────────┬────────────────────────┘
                 │
  ┌──────────────▼───────────────────┐
  │                                  │
fact_checker                  ats_formatter
(verify all metrics           (fix structure,
 against ground truth)         headers, format)
  │                                  │
  └──────────────┬───────────────────┘
                 ▼
          voice_extractor
      (fingerprint Krishna's
       natural writing style)
                 │
                 ▼
             humanizer
       (remove AI marks using
        voice fingerprint)
                 │
                 ▼
          cover_letter
       (150-250 words,
        AI-risk scored)
                 │
                 ▼
        report_assembler
    (ATS score, keyword gaps,
     change log, status)
                 │
                END
```

---

## 🧩 NODE SUMMARY TABLE

| Node | Layer | Runs | Purpose | Research Basis |
|------|-------|------|---------|----------------|
| jd_cleaner | 0 | Parallel | Strip noise from JD | - |
| resume_contextualizer | 0 | Parallel | Add LLM context to chunks | Anthropic Contextual Retrieval |
| jd_intelligence | 1 | Parallel | Deep JD analysis + density target | ATS context-based parsing |
| hybrid_indexer | 1 | Parallel | BM25 index | Hybrid RAG research |
| hybrid_retriever | 2 | Sequential | RRF fusion + reranking | ZeroEntropy 2026, 48% improvement |
| rewriter | 3 | Loop (max 3x) | Draft resume — Actor | MAR Reflexion |
| critic | 3 | Loop (max 3x) | Score draft — Evaluator, NO BIAS | MAR paper arXiv 2512.20845 |
| reflector | 3 | Loop (on retry) | Surgical fix instructions | Reflexion (Shinn 2023) |
| fact_checker | 4 | Parallel | Verify all metrics vs ground truth | Scale.jobs, recruiter advice |
| ats_formatter | 4 | Parallel | Structure compliance | ATS research |
| voice_extractor | 5 | Sequential | Extract Krishna's voice fingerprint | NEW - AI detection fix |
| humanizer | 5 | Sequential | Remove AI marks, preserve keywords | Ward Resumes 2025 |
| cover_letter | 6 | Sequential | 150-250 word letter + AI risk score | 83% hiring manager stat |
| report_assembler | Final | Sequential | ATS report card + change log | - |

---

## 🚀 QUICK START

```python
from graph import run_optimizer, resume_after_approval

JD = """
[Paste full job description here]
"""

# Step 1: Run until human review checkpoint
result = run_optimizer(
    jd_text=JD,
    company_name="Google",
    role_name="Senior ML Engineer",
    thread_id="google_seniorml_v1",
)

# → Graph pauses here. Check result["draft_resume"]
# → Check result["critic_score"]

# Step 2: Approve (optionally add feedback)
final = resume_after_approval(
    thread_id="google_seniorml_v1",
    feedback="Please emphasize the healthcare domain more in the summary",
)

# Outputs in final:
# final["humanized_resume"]   ← The optimized resume
# final["cover_letter"]       ← The cover letter
# final["ats_score_report"]   ← Full score breakdown
# final["change_log"]         ← What changed and why
```

---

## 📊 SCORING RUBRIC (Critic Agent)

| Dimension | Weight | Criteria |
|-----------|--------|---------|
| Keyword Score | 25pts | JD keywords in context, both forms, density 70-80% |
| Bullet Quality | 25pts | Action verbs, quantified, no pronouns, varied lengths |
| Structure | 25pts | Headers, single-column, reverse-chrono, skills first |
| Humanness | 25pts | No AI clichés, natural rhythm, sounds like engineer |
| **TOTAL** | **100** | **≥85 = pass without retry** |

---

## 🔑 KEY RESEARCH REFERENCES

1. **MAR (Multi-Agent Reflexion)** — arXiv 2512.20845 (Dec 2025)
   *Separation of Actor/Evaluator/Reflector eliminates confirmation bias*
   
2. **Hybrid RAG + RRF** — ZeroEntropy 2026, Neo4j Advanced RAG 2025
   *48% retrieval quality improvement over single-method*

3. **Reflexion** — Shinn et al. 2023
   *Verbal reinforcement cues improve agent performance without fine-tuning*

4. **Contextual Retrieval** — Anthropic 2024
   *Prepending chunk context improves retrieval by 49%*

5. **ATS context-based parsing** — Dice AMA r/cscareerquestions, Scale.jobs 2025
   *Modern ATS detects keyword stuffing — target 70-80% density max*

6. **2-page resume advantage** — ResumeGo study (7,712 resumes)
   *2-page resumes get 2.9x more interviews for experienced candidates*

7. **AI detection in recruiting** — Ward Resumes 2025, Built In 2025
   *"formulaic quality, lack of authentic voice" caught by both humans and ATS AI detectors*

8. **LangGraph state management** — SparkCo.ai 2026
   *TypedDict + reducer-driven schemas prevent state corruption in parallel nodes*
