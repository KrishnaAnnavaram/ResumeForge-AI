"""
═══════════════════════════════════════════════════════════════
  KRISHNA'S AI RESUME OPTIMIZER — LangGraph Pipeline
  
  Architecture:
  ┌─────────────────────────────────────────────────────────┐
  │  PARALLEL PRE-PROCESSING                                 │
  │  jd_cleaner ──────────────────────────────────┐         │
  │  resume_contextualizer ──────────────────────┐│         │
  └──────────────────────────────────────────────┼┼─────────┘
                                                 ││
                                    parallel_sync┘│
                                                  │
  ┌───────────────────────────────────────────────▼─────────┐
  │  PARALLEL INTELLIGENCE                                   │
  │  jd_intelligence ──────────────────────────────────┐    │
  │  hybrid_indexer ───────────────────────────────────┐│   │
  └──────────────────────────────────────────────────  ┘│   ┘
                                                         │
  ┌──────────────────────────────────────────────────────▼──┐
  │  hybrid_retriever                                        │
  └─────────────────────────────────────────────────────────┘
                          │
  ┌───────────────────────▼────────────────────────────────┐
  │  REFLEXION LOOP (max 3x)                                │
  │  rewriter → critic → [route] ──→ reflector ──┐         │
  │                 └──── pass ──────────────────┘│         │
  │                       (score≥85 or loop≥3)    │         │
  └───────────────────────────────────────────────┘         │
                          │
  ┌───────────────────────▼────────────────────────────────┐
  │  HUMAN-IN-THE-LOOP INTERRUPT                            │
  │  (Krishna reviews draft before quality gates)           │
  └────────────────────────────────────────────────────────┘
                          │
  ┌───────────────────────▼────────────────────────────────┐
  │  PARALLEL QUALITY GATES                                 │
  │  fact_checker ─────────────────────────────────────────┐│
  │  ats_formatter ────────────────────────────────────────┘│
  └────────────────────────────────────────────────────────┘
                          │
  voice_extractor → humanizer → cover_letter → report_assembler
═══════════════════════════════════════════════════════════════
"""

from langgraph.graph import StateGraph, START, END
from langgraph.checkpoint.memory import MemorySaver

from state import ResumeState
from agents import (
    jd_cleaner_node,
    resume_contextualizer_node,
    jd_intelligence_node,
    hybrid_indexer_node,
    hybrid_retriever_node,
    rewriter_node,
    critic_node,
    reflector_node,
    should_continue_reflexion,
    fact_checker_node,
    ats_formatter_node,
    voice_extractor_node,
    humanizer_node,
    cover_letter_node,
    report_assembler_node,
)


def build_graph() -> StateGraph:
    """
    Construct the full LangGraph pipeline.
    
    Key design decisions (research-grounded):
    1. Parallel pre-processing: JD cleaning and resume contextualisation
       run simultaneously — no dependency between them.
    2. Parallel intelligence: JD analysis and BM25 index building
       are independent operations, run in parallel.
    3. Reflexion loop: Separate Actor/Evaluator/Reflector agents
       (MAR paper — eliminates single-agent confirmation bias).
    4. Human-in-the-loop INTERRUPT: After reflexion, before quality gates.
       Krishna can approve or add feedback without restarting the full pipeline.
    5. Parallel quality gates: Fact checking and ATS formatting
       are independent checks, run simultaneously.
    """
    builder = StateGraph(ResumeState)

    # ── Register all nodes ──────────────────────────────────
    builder.add_node("jd_cleaner",            jd_cleaner_node)
    builder.add_node("resume_contextualizer", resume_contextualizer_node)
    builder.add_node("jd_intelligence",       jd_intelligence_node)
    builder.add_node("hybrid_indexer",        hybrid_indexer_node)
    builder.add_node("hybrid_retriever",      hybrid_retriever_node)
    builder.add_node("rewriter",              rewriter_node)
    builder.add_node("critic",                critic_node)
    builder.add_node("reflector",             reflector_node)
    builder.add_node("fact_checker",          fact_checker_node)
    builder.add_node("ats_formatter",         ats_formatter_node)
    builder.add_node("voice_extractor",       voice_extractor_node)
    builder.add_node("humanizer",             humanizer_node)
    builder.add_node("cover_letter",          cover_letter_node)
    builder.add_node("report_assembler",      report_assembler_node)

    # ── LAYER 0: Parallel pre-processing ───────────────────
    builder.add_edge(START,               "jd_cleaner")
    builder.add_edge(START,               "resume_contextualizer")

    # ── LAYER 1: Parallel intelligence (wait for both L0 outputs) ──
    # jd_intelligence needs clean_jd → waits for jd_cleaner
    # hybrid_indexer needs resume_chunks → waits for resume_contextualizer
    builder.add_edge("jd_cleaner",            "jd_intelligence")
    builder.add_edge("resume_contextualizer", "hybrid_indexer")

    # ── LAYER 2: Hybrid retrieval (needs both L1 outputs) ───
    builder.add_edge("jd_intelligence", "hybrid_retriever")
    builder.add_edge("hybrid_indexer",  "hybrid_retriever")

    # ── LAYER 3: Reflexion loop ─────────────────────────────
    builder.add_edge("hybrid_retriever", "rewriter")
    builder.add_edge("rewriter",         "critic")

    # Conditional routing after critic
    builder.add_conditional_edges(
        "critic",
        should_continue_reflexion,
        {
            "pass":  "fact_checker",   # Skip to quality gates
            "retry": "reflector",      # Loop back through reflector
        },
    )
    builder.add_edge("reflector", "rewriter")  # Close the loop

    # ── LAYER 4: Parallel quality gates ────────────────────
    # Both run from critic's "pass" exit
    # fact_checker is already wired above
    # ats_formatter also runs from fact_checker (sequential here to
    # allow formatter to see fact-checked draft first)
    builder.add_edge("fact_checker",  "ats_formatter")

    # ── LAYER 5 & 6: Voice → Humanize → Cover Letter ───────
    builder.add_edge("ats_formatter",  "voice_extractor")
    builder.add_edge("voice_extractor", "humanizer")
    builder.add_edge("humanizer",      "cover_letter")
    builder.add_edge("cover_letter",   "report_assembler")
    builder.add_edge("report_assembler", END)

    return builder


def compile_graph(interrupt_before_quality: bool = True):
    """
    Compile the graph with optional HITL interrupt.
    
    interrupt_before_quality=True means the graph PAUSES after the
    reflexion loop completes and before quality gates run.
    Krishna can review the draft and either:
      - Approve: set state["human_approved"] = True and resume
      - Give feedback: set state["human_feedback"] = "..." and
        the rewriter will incorporate it on the next run
    
    This is the CORRECT place for HITL — after AI has done its best
    but before final quality-gating freezes the output.
    """
    builder = build_graph()
    checkpointer = MemorySaver()

    interrupt_nodes = ["fact_checker"] if interrupt_before_quality else []

    return builder.compile(
        checkpointer=checkpointer,
        interrupt_before=interrupt_nodes,
    )


# ── Runner ──────────────────────────────────────────────────
def run_optimizer(
    jd_text: str,
    company_name: str,
    role_name: str,
    thread_id: str = "default",
    interrupt_for_review: bool = True,
) -> dict:
    """
    Main entry point. Paste JD → get optimized resume + cover letter.
    
    Returns:
        On first run (before HITL): partial state up to interrupt
        After approval: full final state with all outputs
    """
    graph = compile_graph(interrupt_before_quality=interrupt_for_review)

    initial_state = {
        "raw_jd":       jd_text,
        "company_name": company_name,
        "role_name":    role_name,
        "loop_count":   0,
        "human_approved": False,
        "human_feedback": "",
        "logs":         [],
        "errors":       [],
    }

    config = {"configurable": {"thread_id": thread_id}}

    print(f"\n{'='*60}")
    print(f"  KRISHNA'S RESUME OPTIMIZER")
    print(f"  Target: {role_name} @ {company_name}")
    print(f"{'='*60}\n")

    # ── Phase 1: Run until interrupt ──
    print("► Running pre-processing and reflexion loop...")
    result = graph.invoke(initial_state, config=config)

    if interrupt_for_review:
        print("\n" + "─"*60)
        print("⏸  HUMAN REVIEW CHECKPOINT")
        print("─"*60)
        print("\nDraft resume ready for your review.")
        print(f"ATS Score so far: {result.get('critic_score', 'N/A')}/100")
        print("\nDRAFT RESUME:")
        print("─"*40)
        print(result.get("draft_resume", "")[:2000] + "...\n")
        print("─"*60)
        print("To continue: call resume_graph.invoke(")
        print('  {"human_approved": True}, config=config)')
        print("Or with feedback: add human_feedback='...' to state")
        print("─"*60)
        return result

    return result


def resume_after_approval(
    thread_id: str,
    feedback: str = "",
) -> dict:
    """
    Resume from HITL interrupt after Krishna approves.
    Optionally include feedback to be incorporated.
    """
    graph = compile_graph(interrupt_before_quality=True)
    config = {"configurable": {"thread_id": thread_id}}

    update = {"human_approved": True}
    if feedback:
        update["human_feedback"] = feedback
        update["reflection_notes"] = f"HUMAN FEEDBACK TO INCORPORATE:\n{feedback}"
        # Force one more rewriter pass if feedback provided
        update["critic_score"] = 0

    print("\n► Resuming — running quality gates, humanizer, and cover letter...")
    result = graph.invoke(update, config=config)

    print("\n" + "="*60)
    print("  ✅ COMPLETE")
    print("="*60)

    report = result.get("ats_score_report", {})
    print(f"\nFinal ATS Score:     {report.get('final_ats_score', 'N/A')}/100")
    print(f"Keyword Density:     {report.get('keyword_density_pct', 'N/A')}%")
    print(f"Keywords Matched:    {len(report.get('keywords_matched', []))}")
    print(f"Fact Check:          {'✅ PASS' if report.get('fact_check_passed') else '⚠️ VIOLATIONS'}")
    print(f"Cover Letter Risk:   {report.get('cover_letter_ai_risk', 'N/A')}/100 (lower=safer)")
    print(f"Cover Letter Words:  {report.get('cover_letter_word_count', 'N/A')}")
    print(f"Reflexion Loops:     {report.get('reflexion_loops_used', 'N/A')}")
    print(f"Status:              {report.get('status', 'N/A')}")

    if report.get("keywords_missing"):
        print(f"\nKeywords not matched: {report['keywords_missing']}")

    print("\n" + "="*60)
    return result
