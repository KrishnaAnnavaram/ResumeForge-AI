"""
═══════════════════════════════════════════════════════════════
  KRISHNA'S AI RESUME OPTIMIZER  — Shared State Schema
  Research-grounded: MAR (Multi-Agent Reflexion), Hybrid RAG,
  LangGraph TypedDict best practices (2025)
═══════════════════════════════════════════════════════════════
"""

from typing import TypedDict, Annotated, Optional
import operator


# ── Reducer helpers ──────────────────────────────────────────
def replace(old, new):
    """Always replace — default LangGraph behaviour for scalars."""
    return new

def append_log(old: list, new: list) -> list:
    """Append-only reducer for audit logs."""
    return (old or []) + (new or [])


# ── Main shared state ─────────────────────────────────────────
class ResumeState(TypedDict):

    # ─── INPUTS ──────────────────────────────────────────────
    raw_jd:             Annotated[str, replace]   # Job description pasted by user
    company_name:       Annotated[str, replace]
    role_name:          Annotated[str, replace]

    # ─── LAYER 0: PRE-PROCESSING ─────────────────────────────
    clean_jd:           Annotated[str, replace]   # Noise-stripped JD
    resume_chunks:      Annotated[list, replace]  # Contextualised chunks [{id, section, text, context}]

    # ─── LAYER 1: INTELLIGENCE ───────────────────────────────
    jd_analysis:        Annotated[dict, replace]  # {keywords, must_haves, nice_haves, tone, seniority,
                                                  #  top_3_focus, red_flags, target_keyword_density}
    bm25_index:         Annotated[object, replace] # BM25Okapi index (in-memory)
    chunk_texts:        Annotated[list, replace]  # Parallel list of chunk texts for BM25

    # ─── LAYER 2: RETRIEVAL ───────────────────────────────────
    retrieved_chunks:   Annotated[list, replace]  # RRF-fused, reranked [{chunk, rrf_score, relevance_note}]

    # ─── LAYER 3: REFLEXION LOOP ─────────────────────────────
    draft_resume:       Annotated[str, replace]   # Current rewritten resume (plain text)
    critic_score:       Annotated[int, replace]   # 0-100 ATS score
    critic_report:      Annotated[dict, replace]  # {score, keyword_gaps, bullet_issues, format_issues, density_issues}
    reflection_notes:   Annotated[str, replace]   # Specific surgical fix instructions
    loop_count:         Annotated[int, replace]   # Current iteration (max 3)

    # ─── LAYER 4: QUALITY GATES ───────────────────────────────
    fact_check_passed:  Annotated[bool, replace]
    fact_violations:    Annotated[list, replace]  # [{original, draft_claim, location}]
    format_fixed_resume:Annotated[str, replace]   # After ATS formatter pass

    # ─── LAYER 5: HUMANIZER ───────────────────────────────────
    voice_fingerprint:  Annotated[dict, replace]  # {rhythm, avg_bullet_len, preferred_verbs, phrasing_style}
    humanized_resume:   Annotated[str, replace]

    # ─── LAYER 6: COVER LETTER ───────────────────────────────
    cover_letter:       Annotated[str, replace]
    cover_letter_score: Annotated[int, replace]   # AI-detection risk score 0-100 (lower = safer)

    # ─── HUMAN-IN-THE-LOOP CHECKPOINT ────────────────────────
    human_approved:     Annotated[bool, replace]  # Set True to release from interrupt
    human_feedback:     Annotated[str, replace]   # Optional free-text feedback

    # ─── OUTPUTS ─────────────────────────────────────────────
    ats_score_report:   Annotated[dict, replace]  # Final report card
    change_log:         Annotated[list, replace]  # [{section, what_changed, why}]

    # ─── AUDIT TRAIL ─────────────────────────────────────────
    logs:               Annotated[list, append_log]  # All agent events, never overwritten
    errors:             Annotated[list, append_log]  # Non-fatal errors, keep going
